<template>
  <div>
      001
  </div>
</template>

<script>
export default {
  name: 'home',
  data () {
    return {
      
    }
  }
}
</script>


<style scoped>

</style>
